#Background

The original XBMC Shoutcast v1.1.1 plugin was rendered broken by an update to the Shoutcast API. Further details here:-

[shoutcastblog](http://www.shoutcastblog.com/2010/09/30/shoutcast-api-update/)

A magical ninja coder posted some updated code here:-

[pastbin](http://pastebin.com/LzJqMQRN)

Unfortunately this didn't work with the latest stable build of XBMC (10.1), hence my attempt at updating the code here.

Enjoy!
