XBMC SVN Installer
~~~~~~~~~~~~~~~~~~

v2.2 (Tue, 25 Dec 2012):
 - Nightly builds from Dropbox (thanks to B4K3D PI)

v2.1 (Sunday, 15 July 2012)
 - Nightly builds location: http://www.xbmc4xbox.org.uk/nightly/

v2.0 (Thursday, 7 June 2012)
 - [Xbox] upgrade - copy Q:\scripts\.modules correctly (thanks to VanZan & whufclee);

v1.9 (Tuesday, 23 August 2011)
 - [Xbox] upgrade - copy Q:\system\profiles.xml (thanks to Gink);
 - [Xbox] upgrade - copy Q:\system\FileZilla Server.xml;
 - [Xbox] upgrade - copy Q:\web (thanks to VanZan);
 - [Xbox] update shortcut cfg - only consider one line .cfg's (avoid updating other larger config files);

v1.8 (Wednesday, 27 April 2011)
 - "news" section is back;
 - handle Xbox RSS server errors (builds);
 - show current build version + date (notification);

v1.7 (Wednesday, 1 December 2010):
 - more shortcut .cfg locations - E:\Dash, E:\Dashboard (thanks to Heimdall);
 - more shortcut .cfg locations - C:\fonts\dashboard (thanks to danofun); 
 - better handling of HTTP server errors;

v1.6 (Sunday, 24 October 2010):
 - news error in Confluence;
 - Confluence skin;

v1.5 (Sunday, 3 October 2010):
 - news (broken);
 - install Xbox build (code inspired from T3CH Upgrader script);

v1.4 (Sunday, 11 July 2010) :
 - download builds (Xbox only);

v1.3 (Saturday, 5 June 2010) :
 - website changes (news);
 - new data URL for skin info (website layout independent, thanks to TheQuestor);
 - MediaStream Redux skin;

v1.21 (Wednesday, 5 May 2010):
 - Italian translation (thanks to KymyA);

v1.2 (Saturday, 20 March 2010):
 - handle both ZIP and RAR archives (RAR might not work on Xbox though);
 - estimate skin download time;
 - display whether skin is Xbox compatible;

v1.1 (Friday, 22 January 2010):
 - website changes;
 - Rapier skinning;